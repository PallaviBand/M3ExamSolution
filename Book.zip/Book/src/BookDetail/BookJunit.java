package BookDetail;

import junit.framework.Assert;

import org.junit.Test;

public class BookJunit {
	
	@Test
	public void booktest()
	{
		
		BookSchema bs=new BookSchema(1,1234,"Akshat","Tembhare",850.00);
		Assert.assertEquals("Akshat", bs.name);
		Assert.assertNotNull(bs.id);
		Assert.assertTrue(bs.test1());
	}
}
