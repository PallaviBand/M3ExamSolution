package BookDetail;

import java.util.*;

public class BookMethod {

	static ArrayList<BookSchema> arr=new ArrayList<BookSchema>();
	static{
	BookSchema b1=new BookSchema(1, 1234, "Wings of Fire", "A P J Abdul Kalam", 750.00);
	BookSchema b2=new BookSchema(2, 1587, "Harry Potter", "J K Rowling", 1650.00);
	BookSchema b3=new BookSchema(3, 5469, "JungleBook", "Rudiyard Kipling", 950.00);
	
	arr.add(b1);
	arr.add(b2);
	arr.add(b3);
	}
	Scanner sc=new Scanner(System.in);
	
	public void AddDetail()
	{
		System.out.println("Enter ID:");
		int id=sc.nextInt();
		
		System.out.println("Enter ISBN:");
		int isbn=sc.nextInt();
		
		System.out.println("Enter Book Name:");
		String name=sc.next();
		
		System.out.println("Enter Author Name:");
		String author=sc.next();
		
		System.out.println("Enter Price:");
		double price=sc.nextDouble();
		BookSchema b4=new BookSchema(id, isbn, name, author , price);
		
		arr.add(b4);
		
	}
	
	public void DisplayDetail()
	{
		for(int i=0; i<arr.size(); i++){
		System.out.println(arr.get(i));}
	}
}
