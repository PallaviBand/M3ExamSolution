package BookDetail;

public class BookSchema {
	
	int id;
	int isbm;
	String name;
	String author;
	double price;
	
	@Override
	public String toString() {
		return "BookSchema id is   "  + id +  "    isbn="   + isbm +   "\n    name is   " + name
				+ "\n author is    " + author + "\n price is   " + price + "/n";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getIsbm() {
		return isbm;
	}
	
	public boolean test1(){
		return False;
	}
	
	
	public void setIsbm(int isbm) {
		this.isbm = isbm;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public BookSchema(int id, int isbm, String name, String author, double price) {
		super();
		this.id = id;
		this.isbm = isbm;
		this.name = name;
		this.author = author;
		this.price = price;
	}
	

}
