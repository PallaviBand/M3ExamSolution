package BookDetail;

import java.util.*;

public class BookUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
		Scanner s=new Scanner(System.in);
		while(true){
		System.out.println("Book System");
		System.out.println("1.Add Book Detail");
		System.out.println("2.Display Book Details");
		System.out.println("3.Exit");
		
		int choice=s.nextInt();
		BookMethod bm=new BookMethod();
		switch(choice)
		{
		
		case 1:
			{
				bm.AddDetail();
				
				break;
			}
		case 2:
			{
				bm.DisplayDetail();
				break;
			}
		case 3:
			{
				System.out.println("Exiting System!");
				System.exit(0);
			}
		default:
			{
				System.out.println("Invalid option");
				break;
			}
		}
		}
	}
}

