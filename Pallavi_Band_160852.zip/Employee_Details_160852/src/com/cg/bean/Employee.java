package com.cg.bean;

public class Employee {
	int EmpId;
	String EmpName;
	String PanCardNo;
	double Salary;
	
	
	/************* Default Constructor of Employee Class ***********/
	public Employee(String Name) {
		super();
		this.EmpId = 001;
		this.EmpName = Name;
		this.PanCardNo = "CEQPK4956K";
		this.Salary = 10000;
	}

	/************* Parameterized Constructor of Employee Class ***********/
	public Employee(int empId, String empName, String panCardNo, double salary) {
		super();
		EmpId = empId;
		EmpName = empName;
		PanCardNo = panCardNo;
		Salary = salary;
	}

	
	/************* Getter and Setter Methods ***********/
	public int getEmpId() {
		return EmpId;
	}

	public void setEmpId(int empId) {
		EmpId = empId;
	}

	public String getEmpName() {
		return EmpName;
	}

	public void setEmpName(String empName) {
		EmpName = empName;
	}

	public String getPanCardNo() {
		return PanCardNo;
	}

	public void setPanCardNo(String panCardNo) {
		PanCardNo = panCardNo;
	}

	public double getSalary() {
		return Salary;
	}

	public void setSalary(double salary) {
		Salary = salary;
	}
	

	/************* To Display Employee Details ***********/
	@Override
	public String toString() {
		return "Employee : \n\n" +
	" EmpId     = " + EmpId + 
	"\n EmpName   = " + EmpName + 
	"\n PanCardNo = " + PanCardNo + 
	"\n Salary    = "+ Salary + 
	"\n Income Tax= " + calculate() + 
	"\n\n";
	}
	
	
	/************* To Calculate Employee Income Tax ***********/
	private double calculate() {

		Service s = new Service();
		double x;
		x = s.tax;
		s.Calculate();
		return x;
	}

}
