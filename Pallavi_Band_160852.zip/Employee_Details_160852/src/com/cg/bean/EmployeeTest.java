package com.cg.bean;

import junit.framework.Assert;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

public class EmployeeTest {
	static EmployeeCollection collectionHelper;
	static Employee pr = null;

	@BeforeClass
	public static void beforeClass() {
		collectionHelper = new EmployeeCollection();
		pr = new Employee(88, "Pratik", "CEQPK4956K", 500000);
	}

	@AfterClass
	public static void afterClass() {
		collectionHelper = null;
		pr = null;
	}

	@Test
	public void testAddNewEmployee() {
		collectionHelper.addNewEmployeeDetails(pr);
		// Assert.assertEquals(4, collectionHelper.getCustList().size());
		Assert.assertNotNull(collectionHelper.toString());

	}

	@Test
	public void testAddNewProduct() {
		collectionHelper.displayEmployeeCount();
		// Assert.assertEquals(4, collectionHelper.getCustList().size());
		Assert.assertNotNull(collectionHelper.toString());

	}

}
