package com.cg.bean;

import java.util.Scanner;

public class Service {

	static EmployeeCollection collectionhelper = null;
	int EmpId;
	String EmpName;
	String PanCardNo;
	double Salary, tax;

	public void getEmployeeDetails() {
		collectionhelper = new EmployeeCollection();

		ClassValidator val = new ClassValidator();

		Scanner scr = new Scanner(System.in);

		System.out.println("Enter Id");
		EmpId = scr.nextInt();
		if (val.EmployeeId(EmpId)) {
			System.out.println("Enter Name");
			EmpName = scr.next();
			if (val.EmployeeName(EmpName)) {
				System.out.println("Enter PanCard Number");
				PanCardNo = scr.next();
				if (val.PanCardNumber(PanCardNo)) {
					System.out.println("Enter Salary");
					Salary = scr.nextDouble();
					if (val.Sal(Salary)) {
						System.out
								.println("Employee Details are Added Successfully\n");
						Employee e = new Employee(EmpId, EmpName, PanCardNo,
								Salary);
						// System.out.println(e);
						collectionhelper.addNewEmployeeDetails(e);
					} else {
						System.out.println("Salary Incorrect : Salary should not be Negative \n");
					}
				} else {
					System.out.println("PanCard Number Incorrect : PanCard Should be 10 digit and should have Aphanumeric characters\n");

				}
			} else {
				System.out.println("Name Incorrect : Name Should only have Aphabets \n");
			}
		} else {
			System.out.println("Id Incorrect : Id should be of 2 digits \n");
		}

	}

	public void dispDetail() {
		Employee e = new Employee("e");
		System.out.println(e);

	}
	
	
	/************* To Calculate the Employee IncomeTax ***********/
	public double Calculate() {
		Employee s = new Employee(EmpId, EmpName, EmpName, Salary);
		double Salary;
		Salary = s.getSalary();

		if (Salary <= 250000) {
			System.out.println("");
		} else if (Salary >= 250001 && Salary <= 500000) {
			System.out.println("IncomeTax is 10 %");
			tax = (Salary * 10) / 100;
			System.out.println(" = " + tax);
		} else if (Salary >= 500001 && Salary <= 1000000) {
			System.out.println("IncomeTax is 20 %");
			tax = (Salary * 20) / 100;
			System.out.println(" = " + tax);
		} else {
			System.out.println("IncomeTax is 30 %");
			tax = (Salary * 30) / 100;
			System.out.println(" = " + tax);
		}
		return tax;

	}
}